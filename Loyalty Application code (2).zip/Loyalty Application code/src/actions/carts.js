import uuid from 'uuid';

// ADD_User
export const addToCart = ({ProductID, UserID, ProductName  = '', Price = 0, Quantity = 0, TotalAmount = 0, Availability = 0} = {}) => ({
  type: 'ADD_TO_CART',
  product: {
    id: uuid(),
    ProductID,
    UserID,
    ProductName,
    Price,
    Quantity,
    TotalAmount,
    Availability
  }
});

// REMOVE_EXPENSE
export const removeFromCart = (id) => ({
  type: 'REMOVE_FROM_CART',
  id
});

// EDIT_EXPENSE
export const editFromCart = (id, updates) => ({
  type: 'EDIT_FROM_CART',
  id,
  updates
});
