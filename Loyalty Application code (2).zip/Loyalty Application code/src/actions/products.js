import uuid from 'uuid';

// ADD_User
export const addProduct = ({ProductName = '', Description = '', ImageURL = '', Price = 0, Availability = 0, TotalSell = 0} = {},CurrentProductID='') => ({
  type: 'ADD_PRODUCT',
  product: {
    id: uuid(),
    ProductName,
    Description,
    ImageURL,
    Price,
    Availability,
    TotalSell
  },
  CurrentProductID
});

// REMOVE_EXPENSE
export const removeProduct = ({ id } = {}) => ({
  type: 'REMOVE_PRODUCT',
  id
});

// EDIT_EXPENSE
export const editProduct = (id, updates) => ({
  type: 'EDIT_PRODUCT',
  id,
  updates
});

export const setCurrentProductID = (CurrentProductID='') => ({
  type: 'SET_CURRENT_PRODUCT_ID',
  CurrentProductID
});