import uuid from 'uuid';

// ADD_User
export const addUser = ({FirstName = '',LastName = '', UserName = '',Pwd = '',Mobile = '',Email = 0} = {}, CurrentUserID='', CurrentUserFullName='') => ({
  type: 'ADD_USER',
  user: {
    id: uuid(),
    FirstName,
    LastName,
    UserName,
    Pwd,
    Mobile,
    Email
  },
  CurrentUserID,
  CurrentUserFullName
});

// REMOVE_EXPENSE
export const removeUser = ({ id } = {}) => ({
  type: 'REMOVE_USER',
  id
});

// EDIT_EXPENSE
export const editUser = (id, updates) => ({
  type: 'EDIT_USER',
  id,
  updates
});

export const setCurrentUserID = ({CurrentUserID,CurrentUserFullName}) => ({
  type: 'SET_CURRENT_USER_ID',
  CurrentUserID,
  CurrentUserFullName
});

export const singOutUser = () => ({
  type: 'SIGN_OUT_USER'
});