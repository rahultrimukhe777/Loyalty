export default (users,{UserName,Pwd}) => {
    const UserDetails = props.users.filter((user) => user.UserName===UserName  && user.Pwd===Pwd)[0];
    if(UserDetails) {
        return {CurrentUserID: UserDetails.id, CurrentUserFullName: UserDetails.FirstName+" "+UserDetails.LastName};
    } else {
        return null;
    }
};