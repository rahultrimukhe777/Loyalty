import setCurrentUserID from '../actions/users';
export default (props,UserName='', Pwd='') => {
    const UserDetails = props.users.filter((user) => user.UserName===UserName  && user.Pwd===Pwd)[0];
    if(UserDetails) {
        return {CurrentUserID: UserDetails.id, CurrentUserFullName: UserDetails.FirstName+" "+UserDetails.LastName};
    } else {
        alert("User ID or Password is incorrect...!!");        
        return null;
    }
};
  