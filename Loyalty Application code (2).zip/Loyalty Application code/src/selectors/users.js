export default (users, { UserName='', Pwd='' }) => {
    const UserDetails = [...users.filter((user) => user.UserName===UserName  && user.Pwd===Pwd)];
    if(UserDetails.length!==0) {
        window.localStorage.setItem('CurrentUserID',UserDetails[0].id);
        return [{FirstName: UserDetails[0].FirstName, LastName: UserDetails[0].LastName, id:UserDetails[0].id, UserName:UserDetails[0].UserName, Mobile:UserDetails[0].Mobile, Email:UserDetails[0].Email}];
    } else {
        window.localStorage.setItem('CurrentUserID','');
        return [];
    }
};
  