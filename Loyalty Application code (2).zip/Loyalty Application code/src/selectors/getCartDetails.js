let GrandTotal = 0;
export default (carts,CurrentUserID) => {
    const ProductInCart = carts.filter((cart)=> cart.UserID===CurrentUserID).map((item)=> {
        GrandTotal+=item.Price*item.Quantity;
        return {ID:item.id,Price:item.Price,Quantity: item.Quantity,ProductName: item.ProductName, Availability: item.Availability};
    });
    return {ProductInCart:ProductInCart, GrandTotal: GrandTotal};
};