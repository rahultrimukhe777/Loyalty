import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import AppRouter from './routers/AppRouter';
import configureStore from './store/configureStore';
import { addExpense } from './actions/expenses';
import { addProduct } from './actions/products';
import { addToCart } from './actions/carts';
import { addUser } from './actions/users';
import { setTextFilter } from './actions/filters';
import getVisibleExpenses from './selectors/expenses';
import 'normalize.css/normalize.css';
import './styles/styles.scss';

const store = configureStore();

store.dispatch(addExpense({ description: 'Water bill', amount: 4500 }));
store.dispatch(addExpense({ description: 'Gas bill', createdAt: 1000 }));
store.dispatch(addExpense({ description: 'Rent', amount: 109500 }));
store.dispatch(addUser({ FirstName:'Alex', LastName:'Zender', UserName: 'Test@1234', Pwd: 'Test@1234', Mobile: '8149832020', Email: 'abc@tcs.com' }));
store.dispatch(addUser({ FirstName:'Crua', LastName:'Zender', UserName: 'Test!1234', Pwd: 'Test!1234', Mobile: '8149832020', Email: 'abc@tcs.com' }));
store.dispatch(addUser({ FirstName:'Alex', LastName:'Zender', UserName: 'Test$1234', Pwd: 'Test$1234', Mobile: '8149832020', Email: 'abc@tcs.com' }));
store.dispatch(addProduct({
  ProductName:'Redmi Note 5 Pro', 
  Description:'5.99 Inch Full HD+ Bright Display Qualcomm Snapdragon 4GB RAM 64 GB Internal Memory Expandable Up to 128 GB. /n12MP + 5MP Dual Rear Camera With Flash 4000 mAh Li Polymer Battery 1.8 GHz octa-core 636 Processor.', 
  ImageURL:'https://images-na.ssl-images-amazon.com/images/I/41VVICCABoL.jpg', 
  Price: 16299, 
  Availability: 5, 
  TotalSell: 0
}));
store.dispatch(addProduct({
  ProductName:'Vivo V9 Pro ', 
  Description:'Black, 6GB RAM, Snapdragon 660AIE\nCamera: 13+2 MP Dual rear camera with Ultra HD, Live Mode, AI Bokeh, HDR, Face Beauty, AR Stickers and many more | 16 MP AI Selfie camera with Face Beauty, AI HDR, Bokeh effect, Group selfie, Live photo, AR stickers./nDisplay: 15.51 centimetres (6.3-inch) FHD+ Fullview display 2.0 and 19:9 aspect ratio, 90 percent screen to body ratio', 
  ImageURL:'https://images-eu.ssl-images-amazon.com/images/G/31/img18/Wireless/Wave1/Vivo/V9Pro/English/v9pro.jpg', 
  Price: 12300, 
  Availability: 25, 
  TotalSell: 2
}));
store.dispatch(addProduct({
  ProductName:'Redmi Note 5 Pro', 
  Description:'5.99 Inch Full HD+ Bright Display Qualcomm Snapdragon 4GB RAM 64 GB Internal Memory Expandable Up to 128 GB. /n12MP + 5MP Dual Rear Camera With Flash 4000 mAh Li Polymer Battery 1.8 GHz octa-core 636 Processor.', 
  ImageURL:'https://images-na.ssl-images-amazon.com/images/I/41VVICCABoL.jpg', 
  Price: 16299, 
  Availability: 5, 
  TotalSell: 0
}));
store.dispatch(addProduct({
  ProductName:'Vivo V9 Pro ', 
  Description:'Black, 6GB RAM, Snapdragon 660AIE\nCamera: 13+2 MP Dual rear camera with Ultra HD, Live Mode, AI Bokeh, HDR, Face Beauty, AR Stickers and many more | 16 MP AI Selfie camera with Face Beauty, AI HDR, Bokeh effect, Group selfie, Live photo, AR stickers./nDisplay: 15.51 centimetres (6.3-inch) FHD+ Fullview display 2.0 and 19:9 aspect ratio, 90 percent screen to body ratio', 
  ImageURL:'https://images-eu.ssl-images-amazon.com/images/G/31/img18/Wireless/Wave1/Vivo/V9Pro/English/v9pro.jpg', 
  Price: 12300, 
  Availability: 25, 
  TotalSell: 2
}));
store.dispatch(addProduct({
  ProductName:'Redmi Note 5 Pro', 
  Description:'5.99 Inch Full HD+ Bright Display Qualcomm Snapdragon 4GB RAM 64 GB Internal Memory Expandable Up to 128 GB. /n12MP + 5MP Dual Rear Camera With Flash 4000 mAh Li Polymer Battery 1.8 GHz octa-core 636 Processor.', 
  ImageURL:'https://images-na.ssl-images-amazon.com/images/I/41VVICCABoL.jpg', 
  Price: 16299, 
  Availability: 5, 
  TotalSell: 0
}));
store.dispatch(addProduct({
  ProductName:'Vivo V9 Pro ', 
  Description:'Black, 6GB RAM, Snapdragon 660AIE\nCamera: 13+2 MP Dual rear camera with Ultra HD, Live Mode, AI Bokeh, HDR, Face Beauty, AR Stickers and many more | 16 MP AI Selfie camera with Face Beauty, AI HDR, Bokeh effect, Group selfie, Live photo, AR stickers./nDisplay: 15.51 centimetres (6.3-inch) FHD+ Fullview display 2.0 and 19:9 aspect ratio, 90 percent screen to body ratio', 
  ImageURL:'https://images-eu.ssl-images-amazon.com/images/G/31/img18/Wireless/Wave1/Vivo/V9Pro/English/v9pro.jpg', 
  Price: 12300, 
  Availability: 25, 
  TotalSell: 2
}));
store.dispatch(addProduct({
  ProductName:'Redmi Note 5 Pro', 
  Description:'5.99 Inch Full HD+ Bright Display Qualcomm Snapdragon 4GB RAM 64 GB Internal Memory Expandable Up to 128 GB. /n12MP + 5MP Dual Rear Camera With Flash 4000 mAh Li Polymer Battery 1.8 GHz octa-core 636 Processor.', 
  ImageURL:'https://images-na.ssl-images-amazon.com/images/I/41VVICCABoL.jpg', 
  Price: 16299, 
  Availability: 5, 
  TotalSell: 0
}));
store.dispatch(addProduct({
  ProductName:'Vivo V9 Pro ', 
  Description:'Black, 6GB RAM, Snapdragon 660AIE\nCamera: 13+2 MP Dual rear camera with Ultra HD, Live Mode, AI Bokeh, HDR, Face Beauty, AR Stickers and many more | 16 MP AI Selfie camera with Face Beauty, AI HDR, Bokeh effect, Group selfie, Live photo, AR stickers./nDisplay: 15.51 centimetres (6.3-inch) FHD+ Fullview display 2.0 and 19:9 aspect ratio, 90 percent screen to body ratio', 
  ImageURL:'https://images-eu.ssl-images-amazon.com/images/G/31/img18/Wireless/Wave1/Vivo/V9Pro/English/v9pro.jpg', 
  Price: 12300, 
  Availability: 25, 
  TotalSell: 2
}));
store.dispatch(addProduct({
  ProductName:'Redmi Note 5 Pro', 
  Description:'5.99 Inch Full HD+ Bright Display Qualcomm Snapdragon 4GB RAM 64 GB Internal Memory Expandable Up to 128 GB. /n12MP + 5MP Dual Rear Camera With Flash 4000 mAh Li Polymer Battery 1.8 GHz octa-core 636 Processor.', 
  ImageURL:'https://images-na.ssl-images-amazon.com/images/I/41VVICCABoL.jpg', 
  Price: 16299, 
  Availability: 5, 
  TotalSell: 0
}));
store.dispatch(addProduct({
  ProductName:'Vivo V9 Pro ', 
  Description:'Black, 6GB RAM, Snapdragon 660AIE\nCamera: 13+2 MP Dual rear camera with Ultra HD, Live Mode, AI Bokeh, HDR, Face Beauty, AR Stickers and many more | 16 MP AI Selfie camera with Face Beauty, AI HDR, Bokeh effect, Group selfie, Live photo, AR stickers./nDisplay: 15.51 centimetres (6.3-inch) FHD+ Fullview display 2.0 and 19:9 aspect ratio, 90 percent screen to body ratio', 
  ImageURL:'https://images-eu.ssl-images-amazon.com/images/G/31/img18/Wireless/Wave1/Vivo/V9Pro/English/v9pro.jpg', 
  Price: 12300, 
  Availability: 25, 
  TotalSell: 2
}));
store.dispatch(addProduct({
  ProductName:'Redmi Note 5 Pro', 
  Description:'5.99 Inch Full HD+ Bright Display Qualcomm Snapdragon 4GB RAM 64 GB Internal Memory Expandable Up to 128 GB. /n12MP + 5MP Dual Rear Camera With Flash 4000 mAh Li Polymer Battery 1.8 GHz octa-core 636 Processor.', 
  ImageURL:'https://images-na.ssl-images-amazon.com/images/I/41VVICCABoL.jpg', 
  Price: 16299, 
  Availability: 5, 
  TotalSell: 0
}));
store.dispatch(addProduct({
  ProductName:'Vivo V9 Pro ', 
  Description:'Black, 6GB RAM, Snapdragon 660AIE\nCamera: 13+2 MP Dual rear camera with Ultra HD, Live Mode, AI Bokeh, HDR, Face Beauty, AR Stickers and many more | 16 MP AI Selfie camera with Face Beauty, AI HDR, Bokeh effect, Group selfie, Live photo, AR stickers./nDisplay: 15.51 centimetres (6.3-inch) FHD+ Fullview display 2.0 and 19:9 aspect ratio, 90 percent screen to body ratio', 
  ImageURL:'https://images-eu.ssl-images-amazon.com/images/G/31/img18/Wireless/Wave1/Vivo/V9Pro/English/v9pro.jpg', 
  Price: 12300, 
  Availability: 25, 
  TotalSell: 2
}));


const state = store.getState();
console.log(state);
const visibleExpenses = getVisibleExpenses(state.expenses, state.filters);
console.log(visibleExpenses);
console.log(state);
const jsx = (
  <Provider store={store}>
    <AppRouter />
  </Provider>
);

ReactDOM.render(jsx, document.getElementById('app'));
