import React from 'react';
import { connect } from 'react-redux';
import RegisterForm from './RegisterForm';
import { addUser } from '../actions/users';
import Header from './Header';

const Register = (props) => (
    <div>
        <Header />
        <div className="container">
        <RegisterForm
                onSubmit={(user) => {
                    props.dispatch(addUser(user));
                    alert("Successfully registered...!!!");
                    props.history.push('/Login');
                }}
            />
        </div>
    </div>
);

export default connect()(Register);