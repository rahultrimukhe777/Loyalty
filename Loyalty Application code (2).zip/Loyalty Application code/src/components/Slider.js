import React from 'react';
import { connect } from 'react-redux';
import SliderItem from './SliderItem';
import selectUsers from '../selectors/users';
import { addToCart } from '../actions/carts';
import { NavLink } from 'react-router-dom';

class Slider extends React.Component {
    constructor(props) {
        super(props);
        this.AddToCart = this.AddToCart.bind(this);
    }

    AddToCart(e) {
        e.preventDefault();
        console.log(this.props);
        var {id,ProductName,Price,Availability,TotalSell} = this.props.products.filter((product)=>product.id===e.target.id)[0];
        if(this.props.carts.filter((cart)=>cart.ProductID===id && cart.UserID===this.props.CurrentUserID).length>0) {
            alert("Item is already in cart");
        }else if(Availability===0){
            alert("Item is in out of stock, please try after sometime...");
        } else {
            this.props.dispatch(addToCart({ ProductID: id, UserID: this.props.CurrentUserID, ProductName: ProductName, Price: Price, Quantity: 1, Availability: Availability}));
            alert("Successfully Added into a cart...:)");
        }
    }

    render() {
        return (
            <div id="carousel" className="carousel slide carousel-showmanymoveone" data-ride="carousel" data-interval={this.props.products.lenght}>
                <div className="carousel-inner row no-gutters w-100 mx-auto" role="listbox">
                    <div className="carousel-item active col-sm-4 col-md-3">
                        <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[0].ImageURL} alt="responsive image" className="d-block img-fluid" />
                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[0].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[0].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                        </NavLink>
                    </div>
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[1].ImageURL} alt="responsive image" className="d-block img-fluid" />
                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[1].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[1].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[2].ImageURL} alt="responsive image" className="d-block img-fluid"/>
                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[2].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[2].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[3].ImageURL} alt="responsive image" className="d-block img-fluid"/>
                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                    { this.props.products[3].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[3].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                    
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[4].ImageURL} alt="responsive image" className="d-block img-fluid"/>
                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[4].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[4].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[5].ImageURL} alt="responsive image" className="d-block img-fluid"/>
                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[5].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[5].id} onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[6].ImageURL} alt="responsive image" className="d-block img-fluid"/>

                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[6].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[6].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[7].ImageURL} alt="responsive image" className="d-block img-fluid"/>
                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[7].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[7].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[8].ImageURL} alt="responsive image" className="d-block img-fluid"/>

                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[8].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[8].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                    <div className="carousel-item col-sm-4 col-md-3">
                    <NavLink to="/offers" activeClassName="is-active" exact={true}>
                            <img src={this.props.products[9].ImageURL} alt="responsive image" className="d-block img-fluid"/>

                            <div className="carousel-caption justify-content-center align-items-center">
                                <div>
                                { this.props.products[9].Availability!==0 ? <span className="btn btn-sm btn-secondary" id={this.props.products[9].id}  onClick={this.AddToCart}>Add to Cart</span> : <span className="btn btn-sm btn-secondary">Out of stock</span> }
                                </div>
                            </div>
                            </NavLink>
                    </div>
                </div>
                <a className="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span className="sr-only">Previous</span>
                </a>
                <a className="carousel-control-next" href="#carousel" role="button" data-slide="next">
                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                    <span className="sr-only">Next</span>
                </a>
            </div>
        );
    }
}    
    
const mapStateToProps = (state) => {
    return {
      products: state.products,
      CurrentUserID: state.users.CurrentUserID, 
      carts: state.carts
    };
};

export default connect(mapStateToProps)(Slider);