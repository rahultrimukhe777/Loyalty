import React from 'react';
import { connect } from 'react-redux';
import Header from './Header';
import { addToCart } from '../actions/carts';

class Offers extends React.Component {
    constructor(props) {
        super(props);
        this.AddToCart = this.AddToCart.bind(this);
    }

    AddToCart(e) {
        e.preventDefault();
        console.log(this.props);
        var {id,ProductName,Price,Availability,TotalSell} = this.props.Product;
        if(this.props.carts.filter((cart)=>cart.ProductID===id && cart.UserID===this.props.CurrentUserID).length>0) {
            alert("Item is already in cart");
        }else if(Availability===0){
            alert("Item is in out of stock, please try after sometime...");
        } else {
            this.props.dispatch(addToCart({ ProductID: id, UserID: this.props.CurrentUserID, ProductName: ProductName, Price: Price, Quantity: 1, Availability: Availability}));
            alert("Successfully Added into a cart...:)");
        }
    }

    render () {
        return (
            <div>
                {this.props.CurrentUserID===undefined && this.props.history.push('/Login')}
                <Header />
                <div className="jumbotron">
                    <div className="containerBox">
                        <div className="row">
                            <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12 ImageBox">
                                <img className="img-thumbnail itemImage" src={this.props.Product.ImageURL} alt=""/>
                            </div>
                            <div className="col-lg-8 col-md-8 col-sm-12 col-xs-12 ImageBox">
                                <h4>{this.props.Product.ProductName}</h4>
                                <p><b>Price :</b>{this.props.Product.Price} .Rs</p>
                                <span className="btn btn-sm btn-secondary AddToCart" id="test" onClick={this.AddToCart} >Add to Cart</span>
                                <p>{this.props.Product.Description}</p>
                                <span className="Stock">Stock : <b>{this.props.Product.Availability}</b></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
      Product: state.products.filter((Product)=>Product.id===state.products.CurrentProductID)[0],
      carts: state.carts,
      Products: state.products,
      CurrentUserID: state.users.CurrentUserID
    };
};

export default connect(mapStateToProps)(Offers);
