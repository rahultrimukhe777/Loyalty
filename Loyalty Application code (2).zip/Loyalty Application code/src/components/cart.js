import React from 'react';
import selectUsers from '../selectors/users';
import getCartDetails from '../selectors/getCartDetails';
import { connect } from 'react-redux';
import { editFromCart,removeFromCart } from  '../actions/carts';
import Header from './Header';

class Cart extends React.Component {
    constructor(props) {
        super(props);
        this.updateAddCart = this.updateAddCart.bind(this);
        this.updateMinusCart = this.updateMinusCart.bind(this);
        this.removeFromChart = this.removeFromChart.bind(this);
        this.AddTotal = this.AddTotal.bind(this);
        this.state = {
            GrandTotal: 0,
            ProductInCart: []
        }
    }

    AddTotal() {
        var GrandTotal = 0;
        var ProductInCart = this.props.carts.filter((cart)=> cart.UserID===this.props.CurrentUserID).map((item)=> {
            GrandTotal+=item.Price*item.Quantity;
            return {ID:item.id,Price:item.Price,Quantity: item.Quantity,ProductName: item.ProductName, Availability: item.Availability};
        });
        return {ProductInCart:ProductInCart, GrandTotal: GrandTotal};
    }
    updateAddCart(e) {
        e.preventDefault();
        let item = this.props.carts.filter((cart)=>cart.UserID===this.props.CurrentUserID && cart.id===e.target.id)[0];
        if(item.Availability >= item.Quantity+1) {
            item.Quantity = item.Quantity + 1; 
            this.props.dispatch(editFromCart(item.id,item));
        } else {
            alert("Item is not available, please try after some time...");
        }
        
    }

    updateMinusCart(e) {
        e.preventDefault();
        let item = this.props.carts.filter((cart)=>cart.UserID===this.props.CurrentUserID && cart.id===e.target.id)[0];
        item.Quantity = item.Quantity - 1; 
        this.props.dispatch(editFromCart(item.id,item));
    }

    removeFromChart(e) {
        e.preventDefault();; 
        this.props.dispatch(removeFromCart(e.target.id));
    }

    render () {
        var {ProductInCart,GrandTotal} = this.AddTotal();
        return (
            <div>
                <Header />
                <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 ShoppingCart"><h4>Shopping Cart</h4></div>
                { !this.props.CurrentUserID && this.props.history.push('/Login')}
                <div className="CartContainer container">
                    { ProductInCart && ProductInCart.map((item)=> {
                        return (
                            <div>
                                <div className="row">
                                    <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12 PaddingLeft">
                                        <div className="row">
                                            <h6>{item.ProductName} </h6>
                                        </div>                    
                                    </div>
                                    <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12">Price : {item.Price} Rs.</div>
                                    <div className="col-lg-1 col-md-1 col-xs-12 col-sm-12"><a><i className="fa fa-trash" onClick={this.removeFromChart} id={item.ID} aria-hidden="true"></i></a></div>
                                    <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12">Quantity :
                                        <a className="add btn" onClick={item.Quantity!==0 && this.updateMinusCart} id={item.ID} >-1</a> 
                                            {item.Quantity}
                                        <a className="add btn" onClick={ this.updateAddCart } id={item.ID}>+1</a>
                                    </div>
                                    <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12">Rs. {item.Price*item.Quantity}</div>
                                </div><hr/>
                            </div>
                        );
                    })}
                    { ProductInCart && ProductInCart.length > 0 &&
                    <div>
                        <div className="row">
                            <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-1 col-md-1 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                                <h6>Total</h6>
                            </div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12">Rs. {GrandTotal}</div>
                        </div>
                    </div> }
                    { ProductInCart && ProductInCart.length > 0 &&
                    <div>
                        <div className="row">
                            <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-1 col-md-1 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                                <h6>Tax (5%)</h6>
                            </div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12">Rs. {GrandTotal*0.05}</div>
                        </div>
                    </div> }
                    { ProductInCart && ProductInCart.length > 0 && 
                    <div>
                        <div className="row">
                            <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-1 col-md-1 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                                <h6>Shipping</h6>
                            </div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12">Rs. 50</div>
                        </div>
                    </div> }
                    { ProductInCart && ProductInCart.length > 0 && <hr/> }
                    { ProductInCart && ProductInCart.length > 0 &&
                    <div>
                        <div className="row">
                            <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-1 col-md-1 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                <h6>Grand Total</h6>
                            </div>
                            <div className="col-lg-2 col-md-2 col-xs-6 col-sm-6">Rs. {GrandTotal*0.05+GrandTotal+50}</div><br/>
                        </div>
                    </div> }
                    
                </div>
                { ProductInCart && ProductInCart.length > 0 &&
                    <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 ShoppingCart">
                        <div className="row checkout">
                            <div className="col-lg-4 col-md-4 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12"></div>
                            <div className="col-lg-4 col-md-4 col-xs-12 col-sm-12 aDiv"><br/><a className="form-control btn">Checkout</a></div>
                            <div className="col-lg-2 col-md-2 col-xs-12 col-sm-12"></div>
                        </div>
                </div> }
                { this.props.carts.filter((cart)=>cart.UserID===this.props.CurrentUserID).length<=0 && 
                    <div className="alert alert-danger">
                        <strong>Your cart is empty!</strong> Keep shopping...
                    </div>
                }
            </div>  
        );
    }
}

const mapStateToProps = (state) => {
    return {
      products: state.products,
      CurrentUserID: state.users.CurrentUserID,
      carts: state.carts
    };
};

export default connect(mapStateToProps)(Cart);
