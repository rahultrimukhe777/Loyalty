import React from 'react';
const SliderItem = (props) => (
    <div className="carousel-item col-sm-4 col-md-3">
        <a href="https://bootstrapcreative.com/">
            <img src={props.Product.ImageURL} alt="responsive image" className="d-block img-fluid"/>

            <div className="carousel-caption justify-content-center align-items-center">
                <div>
                    <span className="btn btn-sm btn-secondary">Add to Cart</span>
                </div>
            </div>
        </a>
    </div>
);

export default SliderItem;