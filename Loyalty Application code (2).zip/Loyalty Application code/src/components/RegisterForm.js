import React from 'react';
class RegisterForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            UserName: props.user ? props.user.UserName : '',
            Pwd: props.user ? props.user.Pwd : '',
            Mobile: props.user ? props.user.Mobile : '',
            Email: props.user ? props.user.Email : '',
            error: ''
        };
    }

    onFirstNameChange = (e) => {
        const FirstName = e.target.value;
        this.setState(() => ({ FirstName }));
    }

    onLastNameChange = (e) => {
        const LastName = e.target.value;
        this.setState(() => ({ LastName }));
    }

    onUserNameChange = (e) => {
        const UserName = e.target.value;
        this.setState(() => ({ UserName }));
    }

    onPasswordChange = (e) => {
        const Pwd = e.target.value;
        this.setState(() => ({ Pwd }));
    }
    onCnfPasswordChange = (e) => {
        if(this.state.Pwd!==e.target.value) {
            e.target.value = "";
            confirm_password.setCustomValidity("Confirm password does not match");
            alert("Confirm password does not match");
        }
    }

    onMobileChange = (e) => {
        const Mobile = e.target.value;
        this.setState(() => ({ Mobile }));
    }
    
    onEmailChange = (e) => {
        const Email = e.target.value;
        this.setState(() => ({ Email }));
    }

    onSubmit = (e) => {
        e.preventDefault();
        if (!this.state.UserName || !this.state.Pwd || !this.state.Mobile || !this.state.Email) {
            this.setState(() => ({ error: 'Please provide description and amount.' }));
        } else {
            this.setState(() => ({ error: '' }));
            this.props.onSubmit({
                FirstName: this.state.FirstName,
                LastName: this.state.LastName,
                UserName: this.state.UserName,
                Pwd: this.state.Pwd,
                Mobile: this.state.Mobile,
                Email: this.state.Email
            });
        }
    };
    render() {
        return (
            <form action="/action_page.php"  onSubmit={this.onSubmit} className="jumbotron">
                <div className="container">
                <label htmlFor="fname"><b>First Name</b></label>
                    <input 
                        type="text" 
                        placeholder="Enter Username" 
                        name="fname" 
                        required 
                        onBlur={this.onFirstNameChange}    
                    />

                    <label htmlFor="lname"><b>Last Name</b></label>
                    <input 
                        type="text" 
                        placeholder="Enter Last Name" 
                        name="lname" 
                        required 
                        onBlur={this.onLastNameChange}    
                    />

                    <label htmlFor="uname"><b>Username</b></label>
                    <input 
                        type="text" 
                        placeholder="Enter Username" 
                        name="uname" 
                        required 
                        onBlur={this.onUserNameChange}    
                    />

                    <label htmlFor="psw"><b>Password</b></label>
                    <input 
                        type="password" 
                        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                        title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" 
                        placeholder="Enter Password" 
                        name="psw" 
                        id="psw" 
                        required 
                        onBlur={this.onPasswordChange}    
                    /> 

                    <label htmlFor="cnfpwd"><b>Confirm Password</b></label>
                    <input 
                        type="password" 
                        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                        title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" 
                        placeholder="Confirm Password" 
                        name="cnfpsw" 
                        id="cnfpsw" 
                        required 
                        onBlur={this.onCnfPasswordChange}
                    /> 

                    <label htmlFor="Mobile Number"><b>Mobile Number</b></label>
                    <input 
                        type="number" 
                        placeholder="Enter Mobile Number" 
                        name="MobileNumber" 
                        id="MobileNumber" 
                        required 
                        onBlur={this.onMobileChange}      
                    /> 

                    <label htmlFor="Email"><b>Email</b></label>
                    <input 
                        type="text" 
                        pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" 
                        title="Please enter correct Email... " 
                        placeholder="Enter Email" 
                        name="Email" 
                        id="Email" 
                        required 
                        onBlur={this.onEmailChange} 
                    /> 
                    <button type="submit">Register</button>
                    <label><input type="checkbox" checked="checked" name="remember"   /> Remember me</label>
                </div>

                <div className="container" >
                    <button type="button" className="cancelbtn">Cancel</button>
                    <span className="psw">Forgot <a href="#">password?</a></span>
                </div>
            </form>
        );
    }
}

export default RegisterForm;