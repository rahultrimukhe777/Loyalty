import React from 'react';
import { connect } from 'react-redux';
import LoginForm from './LoginForm';
import { checkUserLogin } from '../actions/filters';
import UserValidation from '../selectors/UserValidation';
import { setCurrentUserID } from '../actions/users';
import Header from './Header';
import selectUsers from '../selectors/users';
const Login = (props) => (
    <div>
        <Header />
        <div className="container">
        <LoginForm onSubmit={(user) => props.dispatch(setCurrentUserID(UserValidation(props,user.UserName,user.Pwd))) ? props.history.push('/') : alert("User ID or Password is inccorect...!")} />
        </div>
    </div>
);

const mapStateToProps = (state) => {
    return {
        users: state.users
    };
};

export default connect(mapStateToProps)(Login);