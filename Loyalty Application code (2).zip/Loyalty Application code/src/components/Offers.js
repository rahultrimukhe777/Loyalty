import React from 'react';
import { connect } from 'react-redux';
import Header from './Header';
import { addToCart } from '../actions/carts';
import { setCurrentProductID } from '../actions/products';

class Offers extends React.Component {
    constructor(props) {
        super(props);
        this.AddToCart = this.AddToCart.bind(this);
    }

    AddToCart(e) {
        e.preventDefault();
        console.log(this.props);
        var {id,ProductName,Price,Availability,TotalSell} = this.props.Products.filter((product)=>product.id===e.target.id)[0];
        if(this.props.carts.filter((cart)=>cart.ProductID===id && cart.UserID===this.props.CurrentUserID).length>0) {
            alert("Item is already in cart");
        }else if(Availability===0){
            alert("Item is in out of stock, please try after sometime...");
        } else {
            this.props.dispatch(addToCart({ ProductID: id, UserID: this.props.CurrentUserID, ProductName: ProductName, Price: Price, Quantity: 1, Availability: Availability}));
            alert("Successfully Added into a cart...:)");
        }
    }

    render () {
        return (
            <div>
                <Header />
                <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 ShoppingCart"><h4>Exciting Latest Offers</h4></div>
                { !this.props.CurrentUserID && this.props.history.push('/Login')}
                <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 ContainerBox">
                    <div className="row">
                        {
                            this.props.Products.map((Product)=> {
                                return (
                                    <div className="col-lg-3 col-md-4 col-sm-10 col-xs-10 img-thumbnail ImgItem">
                                        <div className="ItemConainer row">
                                            <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 ImageBox">
                                                <img className="img-thumbnail itemImage" src={Product.ImageURL} alt=""/>
                                            </div>
                                            <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <h5><a className="ProductPage" onClick={() => this.props.dispatch(setCurrentProductID(Product.id)) && this.props.history.push('/product')}s>{Product.ProductName}</a></h5>
                                                <p><b>Price :</b>{Product.Price} .Rs</p>
                                                <div className="Description"><p>{Product.Description.substring(0, 200)}...<br/><a className="ProductPage" onClick={() => this.props.dispatch(setCurrentProductID(Product.id)) && this.props.history.push('/product')}>See more</a></p></div>
                                                <span className="Stock">Stock : <b>{Product.Availability}</b></span>
                                                <span className="btn btn-sm btn-secondary btnAdd" id={Product.id} onClick={this.AddToCart} >Add to Cart</span>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })
                        }
                        
                    </div>
                </div>
            </div>  
        );
    }
}

const mapStateToProps = (state) => {
    return {
      Products: state.products,
      carts: state.carts,
      CurrentUserID: state.users.CurrentUserID
    };
};

export default connect(mapStateToProps)(Offers);
