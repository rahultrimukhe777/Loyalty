import React from 'react';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import getCartDetails from '../selectors/getCartDetails';
import singOutUser from '../actions/users';
const TopNavigation = (props) => (
    <div className="collapse navbar-collapse" id="navbarTogglerDemo03">
        {window.scrollTo(0,0)}
        <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
            <li className="nav-item active col-lg-4 col-md-12 col-sm-12 colxs-12"></li>
        </ul>
        { props.CurrenUserID && <NavLink to="/" className="nav-link" activeClassName="is-active" exact={true} >Home</NavLink>}
        { props.CurrenUserID && <NavLink to="/offers" className="nav-link" activeClassName="is-active" exact={true} >Offers</NavLink>} 
        { !props.CurrenUserID && <NavLink to="/Register" className="nav-link" activeClassName="is-active" ><span className="Signin"> Register <i className="fa fa-user-plus" aria-hidden="true"></i></span></NavLink>}
        { !props.CurrenUserID && <NavLink to="/Login" className="nav-link" activeClassName="is-active"><span className="Signin"> Login <i className="fa fa-sign-in" aria-hidden="true"></i></span></NavLink>}
        { props.CurrenUserID && 
            <NavLink 
                to="/cart" 
                className="nav-link" 
                activeClassName="is-active" 
                exact={true}>Cart
                <i className="fa fa-cart-arrow-down" aria-hidden="true"></i> 
                <sup>{props.TotalCartsItems}</sup>
            </NavLink>
        } 
        { props.CurrenUserID && <label id="Title"><span className="Signin">Welcome : <b>{props.CurrentUserName}</b></span></label>}
       
        { props.CurrenUserID &&  
        <NavLink 
                to="" 
                className="nav-link" 
                activeClassName="is-active"
                onClick={() => {
                    props.dispatch(singOutUser());
                    props.history.push('/Login');
                }}
            >
                <span className="Signin"> Sign Out 
                    <i className="fa fa-sign-out" aria-hidden="true"></i>
                </span>
            </NavLink> 
        }
        
    </div>
);

const mapStateToProps = (state) => {
    return {
        users: state.users,
        CurrenUserID: state.users.CurrentUserID,
        CurrentUserName: state.users.CurrentUserFullName,
        TotalCartsItems: state.users.CurrentUserID  ? getCartDetails(state.carts,state.users.CurrentUserID).ProductInCart.length : ''
    };
};

export default connect(mapStateToProps)(TopNavigation);