import React from 'react';
import { Link } from 'react-router-dom';

const UserListItem = ({ id, UserName, Email, Mobile }) => (
  <div>
    <Link to={`/edit/${id}`}>
      <h3>{UserName}</h3>
    </Link>
    <p>{Email} - {Mobile}</p>
  </div>
);

export default UserListItem;
