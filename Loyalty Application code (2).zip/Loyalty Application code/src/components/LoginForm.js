import React from 'react';
class LoginForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            UserName: props.user ? props.user.UserName : '',
            Pwd: props.user ? props.user.Pwd : '',
            error: ''
        };
    }

    onUserNameChange = (e) => {
        const UserName = e.target.value;
        this.setState(() => ({ UserName }));
    }

    onPasswordChange = (e) => {
        const Pwd = e.target.value;
        this.setState(() => ({ Pwd }));
    }

    onSubmit = (e) => {
        e.preventDefault();
        if (!this.state.UserName || !this.state.Pwd ) {
            this.setState(() => ({ error: 'Please provide User id and password.' }));
        } else {
            this.setState(() => ({ error: '' }));
            this.props.onSubmit({
                UserName: this.state.UserName,
                Pwd: this.state.Pwd
            });
        }
    };

    render() {
        return (
            <form action="/action_page.php" onSubmit={this.onSubmit} className="jumbotron">
                <div className="imgcontainer">
                    <img src="./images/img_avatar2.png" alt="Avatar" className="avatar" />
                </div>
                <div className="container">
                    <label htmlFor="uname"><b>Username</b></label>
                    <input 
                        type="text"
                        onChange={this.onUserNameChange}
                        placeholder="Enter Username"
                        name="uname"
                        required
                    />

                    <label htmlFor="psw"><b>Password</b></label>
                    <input 
                        type="password"
                        onChange={this.onPasswordChange}
                        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                        title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" 
                        placeholder="Enter Password"
                        name="psw"
                        required
                    /> 

                    <button type="submit">Login</button>
                    <label><input type="checkbox" checked="checked" name="remember" /> Remember me</label>
                </div>

                <div className="container" >
                    <button type="button" className="cancelbtn">Cancel</button>
                    <span className="psw">Forgot <a href="#">password?</a></span>
                </div>
            </form>
        );
    }
}

export default LoginForm;