// Users Reducer

const cartReducerDefaultState = [];

export default (state = cartReducerDefaultState, action) => {
  switch (action.type) {
    case 'ADD_TO_CART':
      return [
        ...state,
        action.product
      ];
    case 'REMOVE_FROM_CART':
      return state.filter(({ id }) => id !== action.id);
    case 'EDIT_FROM_CART':
      return state.map((product) => {
        if (product.id === action.id) {
          return {
            ...product,
            ...action.updates
          };
        } else {
          return product;
        };
      });

    default:
      return state;
  }
};
