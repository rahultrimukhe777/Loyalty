// Users Reducer

const usersReducerDefaultState = [];

export default (state = usersReducerDefaultState, action) => {
  switch (action.type) {

    case 'ADD_USER':
      return [
        ...state,
        action.user
      ];

    case 'REMOVE_USER':
      return state.filter(({ id }) => id !== action.id);

    case 'EDIT_USER':
      return state.map((user) => {
        if (user.id === action.id) {
          return {
            ...user,
            ...action.updates
          };
          console.log(this.state);
        } else {
          return user;
        };
      });

    case 'SET_CURRENT_USER_ID':   
      state.CurrentUserID = action.CurrentUserID; 
      state.CurrentUserFullName = action.CurrentUserFullName; 
      return state; 

    case 'SIGN_OUT_USER': 
      state.CurrentUserID = undefined; 
      state.CurrentUserFullName = undefined; 
      return state; 
      
    default:
      return state;
  }
};
