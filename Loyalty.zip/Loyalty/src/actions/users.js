import uuid from 'uuid';

// ADD_User
export const addUser = ({UserName = '',Pwd = '',Mobile = '',Email = 0} = {}) => ({
  type: 'ADD_USER',
  user: {
    id: uuid(),
    UserName,
    Pwd,
    Mobile,
    Email
  }
});

// REMOVE_EXPENSE
export const removeUser = ({ id } = {}) => ({
  type: 'REMOVE_USER',
  id
});

// EDIT_EXPENSE
export const editUser = (id, updates) => ({
  type: 'EDIT_USER',
  id,
  updates
});
