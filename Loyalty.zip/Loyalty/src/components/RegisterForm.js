import React from 'react';
class RegisterForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            UserName: props.user ? props.user.UserName : '',
            Pwd: props.user ? props.user.Pwd : '',
            Mobile: props.user ? props.user.Mobile : '',
            Email: props.user ? props.user.Email : '',
            error: ''
        };
    }

    onUserNameChange = (e) => {
        const UserName = e.target.value;
        this.setState(() => ({ UserName }));
    }

    onPasswordChange = (e) => {
        const Pwd = e.target.value;
        this.setState(() => ({ Pwd }));
    }

    onCnfPasswordChange = (e) => {
        const Pwd = e.target.value;
        this.setState(() => ({ Pwd }));
    }

    onMobileChange = (e) => {
        const Mobile = e.target.value;
        this.setState(() => ({ Mobile }));
    }
    
    onEmailChange = (e) => {
        const Email = e.target.value;
        this.setState(() => ({ Email }));
    }

    onSubmit = (e) => {
        e.preventDefault();
        if (!this.state.UserName || !this.state.Pwd || !this.state.Mobile || !this.state.Email) {
            this.setState(() => ({ error: 'Please provide description and amount.' }));
        } else {
            this.setState(() => ({ error: '' }));
            this.props.onSubmit({
                UserName: this.state.UserName,
                Pwd: this.state.Pwd,
                Mobile: this.state.Mobile,
                Email: this.state.Email
            });
        }
    };
    render() {
        return (
            <form action="/action_page.php"  onSubmit={this.onSubmit} className="jumbotron">
                <div className="container">
                    <label htmlFor="uname"><b>Username</b></label>
                    <input 
                        type="text" 
                        placeholder="Enter Username" 
                        name="uname" 
                        required 
                        onChange={this.onUserNameChange}    
                    />

                    <label htmlFor="psw"><b>Password</b></label>
                    <input 
                        type="password" 
                        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                        title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" 
                        placeholder="Enter Password" 
                        name="psw" 
                        id="psw" 
                        required 
                        onChange={this.onPasswordChange}    
                    /> 

                    <label htmlFor="cnfpwd"><b>Confirm Password</b></label>
                    <input 
                        type="password" 
                        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                        title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" 
                        placeholder="Confirm Password" 
                        name="cnfpsw" 
                        id="cnfpsw" 
                        required 
                        onChange={this.onCnfPasswordChange}
                    /> 

                    <label htmlFor="Mobile Number"><b>Mobile Number</b></label>
                    <input 
                        type="text" 
                        placeholder="Enter Mobile Number" 
                        name="MobileNumber" 
                        id="MobileNumber" 
                        required 
                        onChange={this.onMobileChange}      
                    /> 

                    <label htmlFor="Email"><b>Email</b></label>
                    <input 
                        type="text" 
                        pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" 
                        title="Please enter correct Email... " 
                        placeholder="Enter Email" 
                        name="Email" 
                        id="Email" 
                        required 
                        onChange={this.onEmailChange} 
                    /> 
                    <button type="submit">Register</button>
                    <label><input type="checkbox" checked="checked" name="remember"   /> Remember me</label>
                </div>

                <div className="container" >
                    <button type="button" className="cancelbtn">Cancel</button>
                    <span className="psw">Forgot <a href="#">password?</a></span>
                </div>
            </form>
        );
    }
}

export default RegisterForm;