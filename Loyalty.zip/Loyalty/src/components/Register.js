import React from 'react';
import { connect } from 'react-redux';
import RegisterForm from './RegisterForm';
import { addUser } from '../actions/users';

const Register = (props) => (
    <div className="container">
       <RegisterForm
            onSubmit={(user) => {
                props.dispatch(addUser(user));
                alert("Successfully registered...!!!");
                props.history.push('/Login');
            }}
        />
    </div>
);

export default connect()(Register);