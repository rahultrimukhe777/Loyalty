import React from 'react';
import ExpenseList from './ExpenseList';
import ExpenseListFilters from './ExpenseListFilters';
import UserList from './UserList';

const ExpenseDashboardPage = () => (
  <div>
    <section className="content-section" id="portfolio">
      <div className="jumbotron">
        <div className="row no-gutters">
          <div className="col-lg-6">
            <a className="portfolio-item" href="#">
              <span className="caption">
              </span>
              <img className="img-fluid" src="https://www.pos-media.eu/wp-content/uploads/2016/08/Promo_Leerdammer-II.jpg" alt=""/>
            </a>
          </div>
          <div className="col-lg-6">
            <a className="portfolio-item" href="#">
              <span className="caption">
                
              </span>
              <img className="img-fluid" src="https://www.velocityprint.com/wp-content/uploads/2017/09/VelocityPromoItems3.png" alt="" />
            </a>
          </div>
          <div className="col-lg-6">
            <a className="portfolio-item" href="#">
              <span className="caption">
                
              </span>
              <img className="img-fluid" src="https://www.onlyinfotech.com/wp-content/uploads/2018/08/1535366262_211_How-to-Find-Products-and-Work-with-Dropshipping-Suppliers-in-2018-Affliate-Marketing.jpg" alt="" />
              
            </a>
          </div>
          <div className="col-lg-6">
            <a className="portfolio-item" href="#">
              <span className="caption">
                
              </span>
              <img className="img-fluid" src="https://www.pos-media.com.ua/wp-content/uploads/2016/08/Promo_Bohemia-chips.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
    </section>
    <ExpenseListFilters />
    <ExpenseList />
    <UserList />
  </div>
);

export default ExpenseDashboardPage;
