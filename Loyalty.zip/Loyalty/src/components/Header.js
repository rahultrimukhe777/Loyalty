import React from 'react';
import TopNavigation from './TopNavigation';

const Header = () => (
  <header className="header">
  <div className="box-menu"> 
        <div className="bar-menu">
          <div className="top-bar clearfix">
            <div className="dropdown">
              <button className="lang-menu"><a href=""><img src="https://image.flaticon.com/icons/svg/206/206839.svg" alt="IT" /></a></button>
              <div id="myDropdown" className="lang-content">
                <a href="#"><img src="https://image.flaticon.com/icons/svg/206/206592.svg" alt="EN" /></a>
                <a href="#"><img src="https://image.flaticon.com/icons/svg/206/206657.svg" alt="FR" /></a>
                <a href="#"><img src="https://image.flaticon.com/icons/svg/206/206724.svg" alt="ES" /></a>
              </div>
            </div>
            <ul>
              <li><a href="#"><i className="fa fa-behance"></i></a></li>
              <li><a href="#"><i className="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i className="fa fa-facebook"></i></a></li>
              <li><a href="#"><i className="fa fa-twitter"></i></a></li>
              <li><a href="#"><i className="fa fa-instagram"></i></a></li>
              <li><a href="#"><i className="fa fa-youtube"></i></a></li>
              <li><a href="#"><i className="fa fa-github"></i></a></li>
              <li><a href="#"><i className="fa fa-codepen"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
  <nav className="navbar navbar-expand-lg navbar-light bg-light">
    <a href="" className="logo col-lg-2 col-md-12 col-sm-12 colxs-12"  data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation"><img src="./images/logo.png" alt="" /></a>
    <TopNavigation />
</nav>
  </header>
);

export default Header;
