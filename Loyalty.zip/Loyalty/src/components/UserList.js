import React from 'react';
import { connect } from 'react-redux';
import selectUsers from '../selectors/users';
import UserListItem from './UserListItem';

const UserList = (props) => (
  <div>
    <h1>Expense List</h1>
    {props.users.map((user) => {
        return <UserListItem key={user.id} {...user} />;
    })}
  </div>
);

const mapStateToProps = (state) => {
  return {
    users: selectUsers(state.users, state.filters)
  };
};

export default connect(mapStateToProps)(UserList);
