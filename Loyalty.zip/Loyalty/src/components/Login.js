import React from 'react';
import { connect } from 'react-redux';
import LoginForm from './LoginForm';
import { checkUserLogin } from '../actions/filters';
const Login = (props) => (
    <div className="container">
       <LoginForm
            onSubmit={(user) => {
                const User = props.dispatch(checkUserLogin(user.UserName,user.Pwd));
            }}
        />
    </div>
);

const mapStateToProps = (state) => {
    return {
        filters: state.filters
    };
};

export default connect(mapStateToProps)(Login);