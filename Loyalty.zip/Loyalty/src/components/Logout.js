import React from 'react';
import { connect } from 'react-redux';
import LoginForm from './LoginForm';
import { checkUserLogin } from '../actions/filters';
const Login = (props) => (
    <div className="container">
       <LoginForm
            onSubmit={() => {
                const User = props.dispatch(checkUserLogin('',''));
                alert("Successfully Loged In...!!!");
                props.history.push('/Login');
            }}
        />
    </div>
);

const mapStateToProps = (state) => {
    return {
        filters: state.filters
    };
};

export default connect(mapStateToProps)(Login);