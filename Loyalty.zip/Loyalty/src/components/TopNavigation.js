import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import selectUsers from '../selectors/users';
import React from 'react';
const TopNavigation = (props) => (
    <div className="collapse navbar-collapse" id="navbarTogglerDemo03">
        <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
            <li className="nav-item active col-lg-4 col-md-12 col-sm-12 colxs-12"></li>
        </ul>
        {console.log(props.users.length)}
        <NavLink to="/" className="nav-link" activeClassName="is-active" exact={true} >Home</NavLink>
        {/* <NavLink to="/create" className="nav-link" activeClassName="is-active">Create Expense</NavLink> */}
        {/* <NavLink to="/help" className="nav-link" activeClassName="is-active">About US</NavLink> */}
        { props.users.length===0 && <NavLink to="/Register" className="nav-link" activeClassName="is-active" ><span className="Signin"> Register <i className="fa fa-user-plus" aria-hidden="true"></i></span></NavLink> }
        { props.users.length===0 && <NavLink to="/Login" className="nav-link" activeClassName="is-active"><span className="Signin"> Login <i className="fa fa-sign-in" aria-hidden="true"></i></span></NavLink> }
        { props.users.length!==0 && 
            <NavLink 
                to="/Login" 
                className="nav-link" 
                activeClassName="is-active"
                onClick={() => {
                const User = props.dispatch(checkUserLogin('',''));
                props.history.push('/Login');
            }}
            >
                <span className="Signin"> Logout 
                    <i className="fa fa-sign-in" aria-hidden="true"></i>
                </span>
            </NavLink> 
        }
    </div>
);

const mapStateToProps = (state) => {
    return {
      users: selectUsers(state.users, state.filters)
    };
  };

export default connect(mapStateToProps)(TopNavigation);