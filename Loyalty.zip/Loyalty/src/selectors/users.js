export default (users, { UserName='', Pwd='' }) => {
    const UserDetails = [...users.filter((user) => user.UserName===UserName  && user.Pwd===Pwd)];
    if(UserDetails.length!==0) {
        return [{id:UserDetails[0].id,UserName:UserDetails[0].UserName,Mobile:UserDetails[0].Mobile,Email:UserDetails[0].Email}];
    } else {
        return [];
    }
};
  