var anchors = document.getElementsByTagName('a');
for(var i = 0; i < anchors.length; i++) {
	anchors[i].addEventListener('click', function(e) { 
		e.preventDefault();
		alert(e.target.text);
		window.open(e.target.href, e.target.text, 'width=1000, height=700, left=24, top=24, scrollbars, resizable');
		return false;
	 });
	console.log(anchors[i].text);
}