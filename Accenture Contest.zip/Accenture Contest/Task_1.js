var TotalExternalLInks = document.getElementsByTagName('a');
var TotalDirectInternalLinks = 0,TotalInDirectInternalLinks = 0;
var TotalDirectExternalLinks = 0,TotalIndirectExrenalLink = 0;
var TotalNumberOfArticlesOnPange = 0; 
var TotalExternal = 0,TotalInternal = 0,TotalLinks = 0;
var TotalImages = 0,TotalSVGImages=0;
//Total Images on Page
function getTotalImages() {
	TotalImages = document.getElementsByTagName('img').length;
	TotalSVGImages = document.getElementsByTagName('svg').length;
}

// Calculate Total number of articles on the page
function getTotalArticals() {
	for(var i=0;i<TotalExternalLInks.length;i++) {
		if(TotalExternalLInks[i].href.toString().indexOf("articles")!=-1) { 
			++TotalNumberOfArticlesOnPange;	
		}
	}
}

// Calculate Total Links on page External/Internal
function getExternalLinks() {
	for(var i=0;i<TotalExternalLInks.length;i++) {
		if(TotalExternalLInks[i].href.toString().indexOf("http")!=-1) {	
			if(TotalExternalLInks[i].href.toString().indexOf(window.location.host)!=-1) {
				if(TotalExternalLInks[i].href.toString().indexOf("r=")!=-1){
					++TotalIndirectExrenalLink;
				} else {
					++TotalDirectInternalLinks;
				}
			}else {
				++TotalDirectExternalLinks;
			}
		} else if(TotalExternalLInks.length>=TotalDirectInternalLinks+TotalDirectExternalLinks) {
			if(TotalExternalLInks[i].href.toString().indexOf('javascript')!=-1){
				++TotalInDirectInternalLinks;
			} else if(TotalExternalLInks[i].href.toString().indexOf('javscript')!=-1) {
				++TotalInDirectInternalLinks;
			} else {
				if(TotalExternalLInks[i].onclick && TotalExternalLInks[i].onclick.toString().indexOf('r=')!=-1) {
					++TotalIndirectExrenalLink;
				} else {
					console.log("Not Checked for this link\n",TotalExternalLInks[i]);
				}
			}
		} else {
			console.log("Not Checked for this link",TotalExternalLInks[i]);
		}
	}
	TotalExternal = TotalDirectExternalLinks + TotalIndirectExrenalLink;
	TotalInternal = TotalDirectInternalLinks + TotalInDirectInternalLinks;
	TotalLinks = TotalInternal + TotalExternal;
}

clear();
 
console.log('----------------------------------- Total Number of Images on Page ------------------------------------');
getTotalImages();
console.log('Number of simple Images on page : ', TotalImages);
console.log('Number of SVG Images on Page : ',TotalSVGImages);
console.log('Total number of Images on Page : ',TotalImages+TotalSVGImages);

console.log('\n----------------------------------- Total Number of articles on Page ---------------------------------');
getTotalArticals();
console.log("Total Articles on the page is :",TotalNumberOfArticlesOnPange);

console.log('\n-------------------------- Total Number of External/Internal links on Page ---------------------------');
getExternalLinks();
console.log('Total external Links are : ',TotalExternal);
console.log('Total Internal Links are : ',TotalInternal);
console.log('Total Calculated Links are : ',TotalLinks);
console.log('Total Page Links are :', TotalExternalLInks.length);